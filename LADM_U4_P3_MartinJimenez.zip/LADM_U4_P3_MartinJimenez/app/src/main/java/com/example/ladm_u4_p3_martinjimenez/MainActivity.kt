package com.example.ladm_u4_p3_martinjimenez

import android.content.pm.PackageManager
import android.database.sqlite.SQLiteException
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var dataLista = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cargarLista()
        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.RECEIVE_SMS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.RECEIVE_SMS),1)}

        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_SMS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.READ_SMS),2)}

        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.SEND_SMS), 3)}

        button.setOnClickListener{
            var noCuenta = txtCuenta.text.toString()
            var nombre = txtNombre.text.toString()
            var saldo = txtSaldo.text.toString()
            if(noCuenta.isEmpty() || nombre.isEmpty() ||saldo.isEmpty()){
                AlertDialog.Builder(this).setTitle("ATENCION").setMessage("llene todos los campos").show()
                return@setOnClickListener
            }

            var arregloF = arrayOf(noCuenta, nombre)
            when(checarSintaxis(arregloF)) {
                0->{
                    try{
                        var baseDatos = BD_Cuentas(this, "CUENTAS",null,1)
                        var insertar = baseDatos.writableDatabase
                        var SQL = "INSERT INTO Cuentas VALUES('${noCuenta}','${nombre}','${saldo}')"
                        insertar.execSQL(SQL)
                        baseDatos.close()
                        cargarLista()
                    }
                    catch(e:SQLiteException){
                        AlertDialog.Builder(this).setTitle("ATENCION").setMessage(e.toString()).show()
                    }
                }
                1->{AlertDialog.Builder(this).setTitle("ATENCION").setMessage("Numero de cuenta a 8 digitos")}
                2->{AlertDialog.Builder(this).setTitle("ATENCION").setMessage("Solo ingresar el primer nombre")}
            }


        }


    }




    private fun cargarLista(){
        try {
            var cursor = BD_Cuentas(this, "CUENTAS", null, 1).readableDatabase
                .rawQuery(
                    "SELECT * FROM CUENTAS",
                    null )

            if(cursor.moveToFirst()){
                dataLista.clear()
                do{
                  var cuenta = "Numero de cuenta: "+cursor.getString(0)+
                          "\nNOMBRE: "+cursor.getString(1)+
                          "\nSALDO: "+cursor.getString(2)
                    dataLista.add(cuenta)
                }while(cursor.moveToNext())

            }

        }catch(e: SQLiteException){
            AlertDialog.Builder(this).setTitle("ATENCION").setMessage("No se pudo acceder a la consulta").show()
        }

        var adaptador = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dataLista)

        lista.adapter = adaptador
    }



    private fun checarSintaxis(arreglo:Array<String>):Int{
        var noCuenta=arreglo[0]
        var nombre = arreglo[1]

        var revNombre = nombre.split(" ")

        if(noCuenta.length!=8 ){
            return 1
        }
        if(revNombre.size!=1){
            return 2
        }

        return 0
    }
}