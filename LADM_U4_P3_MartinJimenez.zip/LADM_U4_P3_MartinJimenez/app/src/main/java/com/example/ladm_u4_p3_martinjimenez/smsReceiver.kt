package com.example.ladm_u4_p3_martinjimenez

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteException
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.widget.Toast

class smsReceiver : BroadcastReceiver() {
    //Sintaxis del mensaje:  ConsultaCuenta #Cuenta8digitos 1erNombre

    var cuenta=""
    var nombre =""
    var info = ""
    override fun onReceive(context: Context, intent: Intent) {
        val extras = intent.extras

        if(extras != null) {
            var sms = extras.get("pdus") as Array<Any>

            for (indice in sms.indices) {
                val formato = extras.getString("format")

                var smsMensaje = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    SmsMessage.createFromPdu(sms[indice] as ByteArray, formato)
                } else {
                    SmsMessage.createFromPdu(sms[indice] as ByteArray)
                }

                var celularOrigen = smsMensaje.originatingAddress
                var contenidoSms = smsMensaje.messageBody.toString()


                Toast.makeText(context, "Entró ${contenidoSms}", Toast.LENGTH_LONG).show()


                var smsArreglo = contenidoSms.split(" ")
                cuenta = smsArreglo[1]
                nombre = smsArreglo[2]

                if (smsArreglo.size != 3) {
                    SmsManager.getDefault().sendTextMessage(celularOrigen,null,"Error en formato de mensaje\nEjemplo: ConsultaCuenta 12345678 Martín",null,null)
                } else {
                    if (!smsArreglo[0].equals("ConsultaCuenta")) {
                        SmsManager.getDefault().sendTextMessage(celularOrigen,null,"Error: Palabra clave incorrecta\nEjemplo: ConsultaCuenta 12345678 Martín",null,null)
                    } else {
                        if (cuenta.length != 8) {

                            SmsManager.getDefault().sendTextMessage(celularOrigen,null,"Error: El número de cuenta son 8 dígitos\nEjemplo: ConsultaCuenta 12345678 Martín",null,null)
                        } else {

                            try {
                                var cursor =BD_Cuentas(context, "CUENTAS", null, 1)
                                    .readableDatabase
                                    .rawQuery("SELECT * FROM CUENTAS WHERE NUMERO_CUENTA = '${smsArreglo[1]}' AND NOMBRE = '${smsArreglo[2]}'",null)

                                if (cursor.moveToFirst()) {
                                    info ="INFORMACIÓN DE CUENTA \nNoCuenta: ${cuenta}"  +
                                                "\nNOMBRE: ${nombre}" +
                                                "\nSALDO: " + cursor.getString(2)

                                    SmsManager.getDefault().sendTextMessage(celularOrigen, null, info, null, null)
                                } else {
                                    SmsManager.getDefault().sendTextMessage(celularOrigen,null,"No existe una cuenta con esos datos",null,null)
                                }
                            } catch (e: SQLiteException) {
                                Toast.makeText(context,e.toString(), Toast.LENGTH_LONG).show()

                            }
                        }
                    }
                }

            }//for
        }//if
    }//onReceive

}
