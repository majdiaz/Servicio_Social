package com.example.ladm_u4_p2_martinjimenez


import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View


class Lienzo (p:MainActivity) : View(p){
    var pBlanco = Figura(BitmapFactory.decodeResource(resources, R.drawable.pblanco),90,190)

    var puntero = p




    override fun onDraw(canvas: Canvas) {



        super.onDraw(canvas)
        var paint = Paint()


        var cuadro = width/8f

        canvas.drawColor(Color.BLACK)
        paint.color = Color.WHITE


        // ------------------------------- TABLERO ----------
        //Linea 1
        canvas.drawRect(cuadro,0f,cuadro*2,cuadro,paint)
        canvas.drawRect(cuadro*3,0f,cuadro*4,cuadro,paint)
        canvas.drawRect(cuadro*5,0f,cuadro*6,cuadro,paint)
        canvas.drawRect(cuadro*7,0f,cuadro*8,cuadro,paint)
        //Linea 2
        canvas.drawRect(0f,cuadro,cuadro,cuadro*2,paint)
        canvas.drawRect(cuadro*2,cuadro,cuadro*3,cuadro*2,paint)
        canvas.drawRect(cuadro*4,cuadro,cuadro*5,cuadro*2,paint)
        canvas.drawRect(cuadro*6,cuadro,cuadro*7,cuadro*2,paint)
        //Linea 3
        canvas.drawRect(cuadro,cuadro*2,cuadro*2,cuadro*3,paint)
        canvas.drawRect(cuadro*3,cuadro*2,cuadro*4,cuadro*3,paint)
        canvas.drawRect(cuadro*5,cuadro*2,cuadro*6,cuadro*3,paint)
        canvas.drawRect(cuadro*7,cuadro*2,cuadro*8,cuadro*3,paint)
        //Linea 4
        canvas.drawRect(0f,cuadro*3,cuadro,cuadro*4,paint)
        canvas.drawRect(cuadro*2,cuadro*3,cuadro*3,cuadro*4,paint)
        canvas.drawRect(cuadro*4,cuadro*3,cuadro*5,cuadro*4,paint)
        canvas.drawRect(cuadro*6,cuadro*3,cuadro*7,cuadro*4,paint)
        //Linea 5
        canvas.drawRect(cuadro,cuadro*4,cuadro*2,cuadro*5,paint)
        canvas.drawRect(cuadro*3,cuadro*4,cuadro*4,cuadro*5,paint)
        canvas.drawRect(cuadro*5,cuadro*4,cuadro*6,cuadro*5,paint)
        canvas.drawRect(cuadro*7,cuadro*4,cuadro*8,cuadro*5,paint)
        //Linea 6
        canvas.drawRect(0f,cuadro*5,cuadro,cuadro*6,paint)
        canvas.drawRect(cuadro*2,cuadro*5,cuadro*3,cuadro*6,paint)
        canvas.drawRect(cuadro*4,cuadro*5,cuadro*5,cuadro*6,paint)
        canvas.drawRect(cuadro*6,cuadro*5,cuadro*7,cuadro*6,paint)
        //Linea 7
        canvas.drawRect(cuadro,cuadro*6,cuadro*2,cuadro*7,paint)
        canvas.drawRect(cuadro*3,cuadro*6,cuadro*4,cuadro*7,paint)
        canvas.drawRect(cuadro*5,cuadro*6,cuadro*6,cuadro*7,paint)
        canvas.drawRect(cuadro*7,cuadro*6,cuadro*8,cuadro*7,paint)
        //Linea 8
        canvas.drawRect(0f,cuadro*7,cuadro,cuadro*8,paint)
        canvas.drawRect(cuadro*2,cuadro*7,cuadro*3,cuadro*8,paint)
        canvas.drawRect(cuadro*4,cuadro*7,cuadro*5,cuadro*8,paint)
        canvas.drawRect(cuadro*6,cuadro*7,cuadro*7,cuadro*8,paint)
        // ------------------------ FIN TABLERO ------------------------

        pBlanco.pintar(canvas,paint)

        paint.color = Color.DKGRAY
        canvas.drawRect(0f,cuadro*8,width.toFloat(),height.toFloat(),paint)
    }//onDraw



    fun moverBlanco(dir:Int) {
        pBlanco.mover(dir,width)
        invalidate()
    }

    fun accion(dir:Int){

    }

}//class lienzo

