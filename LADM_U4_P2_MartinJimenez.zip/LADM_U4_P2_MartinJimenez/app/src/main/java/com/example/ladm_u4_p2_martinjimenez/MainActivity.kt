package com.example.ladm_u4_p2_martinjimenez

import android.content.Context
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class MainActivity : AppCompatActivity(), SensorEventListener  {
    var lienzo:Lienzo? = null

    lateinit var sensorManager: SensorManager



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lienzo = Lienzo(this)
        setContentView(lienzo!!)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager.registerListener(this,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL)
        this.setTitle("Practica 2 Unidad 4")




    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

    }

    override fun onSensorChanged(event: SensorEvent) {

        if(event.values[0]< 0 ){
            var x = lienzo!!.pBlanco.x.toInt()
            var y = lienzo!!.pBlanco.y.toInt()

            lienzo!!.pBlanco=Figura(BitmapFactory.decodeResource(resources, R.drawable.pblanco),x,y)
            lienzo!!.moverBlanco(1)
        }
        if(event.values[0]>0){
            var x = lienzo!!.pBlanco.x.toInt()
            var y = lienzo!!.pBlanco.y.toInt()

            lienzo!!.pBlanco=Figura(BitmapFactory.decodeResource(resources, R.drawable.pnegro),x,y)
            lienzo!!.moverBlanco(2)
        }

    }

}

