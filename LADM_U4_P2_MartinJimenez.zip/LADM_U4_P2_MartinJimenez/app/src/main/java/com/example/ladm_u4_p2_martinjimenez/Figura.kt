package com.example.ladm_u4_p2_martinjimenez

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent

class Figura(){
    var x=0f
    var y=0f
    var r=0f
    var ancho = 0f
    var alto = 0f
    var tipo=1
    var icono:Bitmap? = null




    constructor(imagen:Bitmap, x: Int, y:Int):this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        icono = imagen
        tipo = 3
        this.ancho=imagen!!.width.toFloat()

    }

    fun pintar(canvas:Canvas, paint:Paint ){
        canvas.drawBitmap(icono!!,x,y,paint)

    }//pintar





    fun mover(dir: Int,w:Int){

            if (dir == 1) {
                if(x<w-80)
                x = x + 20
            }
            if (dir == 2) {
                if(x>0)
                x = x - 20
            }

    }




}