package com.example.ladm_u4_contentproviders



import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main3.*
import java.util.*
import kotlin.collections.ArrayList


class Main3Activity : AppCompatActivity() {
var dataLista = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

    if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CALL_LOG)!=PackageManager.PERMISSION_GRANTED){
        ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.READ_CALL_LOG),2)
    }
        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.READ_CONTACTS),3)
        }

        btnRegistro.setOnClickListener {
            obtenerRegistro(this)
        }
    }

    private fun obtenerRegistro(context: Context){
        val contentUri= CallLog.Calls.CONTENT_URI
        dataLista.clear()

        try {
            val cursor =context.contentResolver.query(contentUri,null,null,null,null)

            val nombreUri = cursor!!.getColumnIndex(CallLog.Calls.CACHED_LOOKUP_URI)
            val numeroUri = cursor.getColumnIndex(CallLog.Calls.NUMBER)
            val duracionUri = cursor.getColumnIndex(CallLog.Calls.DURATION)
            val fechaUri = cursor.getColumnIndex(CallLog.Calls.DATE)
            val tipo = cursor.getColumnIndex(CallLog.Calls.TYPE)

            if(cursor.moveToFirst()){
                do{
                    val tipoLlamada = when(cursor.getInt(tipo)){
                        CallLog.Calls.INCOMING_TYPE -> "ENTRANTE"
                        CallLog.Calls.OUTGOING_TYPE ->"SALIENTE"
                        CallLog.Calls.MISSED_TYPE -> "PERDIDA"
                        CallLog.Calls.REJECTED_TYPE ->"RECHAZADA"
                        else-> "no definido"
                    }

                    val numero = cursor.getString(numeroUri)
                    val nombre = cursor.getString(nombreUri)
                    val fecha = cursor.getString(fechaUri)
                    val fechaConFormato = Date(fecha.toLong()).toString()
                    val duracion = cursor.getString(duracionUri)

                    dataLista.add("Nombre: ${obtenerNombre(nombre)}\nNumero: ${numero}\nFecha: ${fechaConFormato}\nDuracion: ${duracion}\nTipo: ${tipoLlamada}")
                }while (cursor.moveToNext())

                var adaptador = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dataLista)
                listaRegistro.adapter = adaptador

            }
            cursor.close()

        }catch (e:SecurityException){
            Toast.makeText(this,"se denegó el permiso",Toast.LENGTH_LONG).show()
        }
    }

    private fun obtenerNombre(n:String):String{
        var nombre=""

        val cursor = contentResolver.query(Uri.parse(n),null,null,null,null)

        if((cursor?.count ?:0) >0 ){
            while(cursor != null && cursor.moveToNext()){
                nombre = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
            }
            cursor?.close()
            return nombre

        }else{
            nombre = "Numero desconocido"
            return nombre
        }


    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode==2){
            Toast.makeText(this,"El permiso de lectura de llamadas fue otorgado",Toast.LENGTH_LONG).show()}
        if(requestCode==3){
            Toast.makeText(this,"El permiso de lectura de contactos fue otorgado",Toast.LENGTH_LONG).show()}
    }



}
