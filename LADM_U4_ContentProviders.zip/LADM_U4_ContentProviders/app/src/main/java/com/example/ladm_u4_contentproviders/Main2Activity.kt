package com.example.ladm_u4_contentproviders




import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main2.*


class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.WRITE_CONTACTS),
                1
            )
        }

        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
        }

        btnRegistrar.setOnClickListener {
            var nombre = txtNombre.text.toString()
            var numero = txtNumero.text.toString()
            var email = txtEmail.text.toString()

            intent.apply {
                // Inserts an email address
                putExtra(ContactsContract.Intents.Insert.EMAIL, email)

                 putExtra(
                     ContactsContract.Intents.Insert.EMAIL_TYPE,
                     ContactsContract.CommonDataKinds.Email.TYPE_WORK
                 )
                // Inserts a phone number
                putExtra(ContactsContract.Intents.Insert.PHONE, numero)


                putExtra(
                    ContactsContract.Intents.Insert.PHONE_TYPE,
                    ContactsContract.CommonDataKinds.Phone.TYPE_WORK
                )
                //Inserts a name contact
                putExtra(ContactsContract.Intents.Insert.NAME,nombre)
            }

            startActivity(intent)
        }

        btnRegresar.setOnClickListener {
            finish()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode == 1){
            Toast.makeText(this,"El permiso de escritura de contactos fue otorgado",Toast.LENGTH_LONG).show()
        }
    }


}
