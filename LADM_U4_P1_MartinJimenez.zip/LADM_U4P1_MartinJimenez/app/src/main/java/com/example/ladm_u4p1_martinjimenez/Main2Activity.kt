package com.example.ladm_u4p1_martinjimenez

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {
    var baseRemota = FirebaseFirestore.getInstance()
    var dataLista = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        btnRegistrar.setOnClickListener {
            if(txtNombre.text.isEmpty() || txtNumero.text.isEmpty()){
                AlertDialog.Builder(this)
                    .setTitle("ATENCION")
                    .setMessage("Por favor llene todos los campos")
                    .setPositiveButton("ok"){d,i->}
                    .show()
            }else {
                insertar()
            }
        }

        btnRegresar.setOnClickListener {
            finish()
        }

        cargarLista()

    }

    private fun cargarLista(){
        dataLista.clear()
        baseRemota.collection("contactos")
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if(firebaseFirestoreException!=null){
                    // si no es null hay un error
                    Toast.makeText(this,"Error, no se puede acceder a los contactos",Toast.LENGTH_LONG).show()

                    return@addSnapshotListener
                }


                for(document in querySnapshot!!){
                    var cadena = "Nombre: "+document.getString("nombre")+"\nNúmero: "+document.getString("numero")+"\nDeseado: "+document.getBoolean("deseado")
                    dataLista.add(cadena)
                }

                if(dataLista.size ==0){
                    dataLista.add("NO HAY DATOS")
                }

                var adaptador = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,dataLista)
                listaContactos.adapter = adaptador
            }

    }

    private fun insertar(){
        dataLista.clear()

            var datosInsertar = hashMapOf(
                "numero" to txtNumero.text.toString(),
                "nombre" to txtNombre.text.toString(),
                "deseado" to checkDeseado.isChecked
            )

            baseRemota.collection("contactos")
                .add(datosInsertar as Any)
                .addOnSuccessListener {
                    Toast.makeText(this, "Se registró a ${txtNombre.text}", Toast.LENGTH_LONG).show()
                    cargarLista()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Importante\n no se logró insertar", Toast.LENGTH_LONG).show()
                }
    }
}
