package com.example.ladm_u4p1_martinjimenez

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main2.*


class IncomingCall : BroadcastReceiver() {
    var baseRemota = FirebaseFirestore.getInstance()
    override fun onReceive(context: Context, intent: Intent) {
        val extras = intent.extras

        if(extras != null){
            if ( extras.getString("state").equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                val numero = extras.getString("incoming_number")
                var deseado = false
                var mensaje = ""
                var nombre = ""
                baseRemota.collection("contactos")
                    .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                        if(firebaseFirestoreException!=null){
                            // si no es null hay un error
                            return@addSnapshotListener
                        }


                        //aqui se compara el numero que llamó con el numero de nuestra agenda
                        for(document in querySnapshot!!){
                           if(document.getString("numero").equals(numero)){
                               //si el numero que llama se encuentra en la agenda entonces se obtiene el campo "deseado"
                                deseado = document.getBoolean("deseado")!!
                               nombre = document.getString("nombre").toString()
                           }
                        }
                    }

                if(deseado){
                    baseRemota.collection("Mensajes")
                        .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                            if (firebaseFirestoreException != null) {
                                // si no es null hay un error
                                return@addSnapshotListener
                            }

                            for (document in querySnapshot!!) {
                                mensaje = document.getString("deseado").toString()
                            }
                        }
                }else{
                    baseRemota.collection("Mensajes")
                        .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                            if (firebaseFirestoreException != null) {
                                // si no es null hay un error
                                return@addSnapshotListener
                            }

                            for (document in querySnapshot!!) {
                                mensaje = document.getString("noDeseado").toString()
                            }
                        }
                }
                    SmsManager.getDefault().sendTextMessage(numero,null,mensaje,null,null)


                var datosInsertar = hashMapOf(
                    "numero" to numero,
                    "nombre" to nombre,
                    "mensaje" to mensaje)

                baseRemota.collection("registro")
                    .add(datosInsertar as Any)

            }
        }//if
    }//evento
}